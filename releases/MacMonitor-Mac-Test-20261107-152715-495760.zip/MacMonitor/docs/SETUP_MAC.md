# 대상 iMac 설치와 외부 접속 설정

## 1. 개발 도구

대상 Mac에서 다음을 준비합니다.

- macOS Monterey 12.5 이상
- Xcode 14.2 및 해당 Command Line Tools
- Go 1.26.x Intel용
- FFmpeg와 `h264_videotoolbox` 인코더

```bash
xcode-select -p
swift --version
go version
ffmpeg -hide_banner -encoders | grep h264_videotoolbox
```

Command Line Tools만으로는 빌드할 수 없습니다. App Store는 Monterey에서 실행되지 않는 최신 Xcode만 제공하므로 https://developer.apple.com/download/all/ 에서 `Xcode_14.2.xip`을 받아 압축을 풀고 `/Applications`로 옮깁니다. Xcode를 한 번 실행해 라이선스 동의와 추가 구성 요소 설치를 마친 뒤 Xcode를 활성 개발자 경로로 선택합니다. `xcode-select -p`가 `/Library/Developer/CommandLineTools`이면 `xcodebuild`가 `tool 'xcodebuild' requires Xcode` 오류로 실패합니다.

```bash
sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
xcodebuild -version   # Xcode 14.2
```

빌드 스크립트는 Monterey 호환성을 위해 Go 1.26.x만 허용합니다.

FFmpeg는 앱이 찾는 `/usr/local/bin/ffmpeg` 또는 `/opt/homebrew/bin/ffmpeg`에 있어야 합니다. Homebrew는 Monterey를 Tier 3로 낮춰 미리 빌드된 bottle이 거의 없으므로 `brew install ffmpeg`는 긴 소스 빌드가 되거나 실패할 수 있습니다. 대신 https://evermeet.cx/ffmpeg/ 의 Intel용 정적 `ffmpeg` 릴리스 ZIP을 받아 Finder에서 압축을 풀고 다음처럼 설치할 수 있습니다. 다운로드 사이트의 최소 macOS 버전과 VideoToolbox 포함 여부는 받을 때 다시 확인합니다.

```bash
sudo mkdir -p /usr/local/bin
sudo cp ~/Downloads/ffmpeg /usr/local/bin/ffmpeg
sudo chmod 755 /usr/local/bin/ffmpeg
sudo xattr -d com.apple.quarantine /usr/local/bin/ffmpeg 2>/dev/null || true
/usr/local/bin/ffmpeg -hide_banner -encoders | grep h264_videotoolbox
```

마지막 명령이 `h264_videotoolbox` 줄을 출력해야 합니다.

## 2. 의존성 및 앱 빌드

Finder에서 저장소 루트의 `Build MacMonitor.command`를 더블클릭하면 아래 준비와 빌드 절차를 한 번에 실행합니다. MediaMTX 1.21.1이 없으면 체크섬 검증 후 내려받고, 스크립트 권한 설정, 일반 테스트와 Thread Sanitizer, 앱 패키징, 실행 전 진단을 거쳐 성공한 앱을 자동 실행합니다. 터미널 출력은 `dist/build-날짜-시간.log`에도 보존되며 실패 시 창을 닫지 않고 오류를 표시합니다.

개별 명령으로 실행하려면 다음 순서를 사용합니다.

```bash
cd "/path/to/mac monitor"
chmod +x scripts/*.sh
./scripts/fetch-mediamtx.sh
./scripts/build-app.sh
./scripts/diagnose.sh
open dist/MacMonitor.app
```

`fetch-mediamtx.sh`는 GitHub의 MediaMTX 1.21.1 Intel archive와 공식 `checksums.sha256`를 HTTPS로 받아 일치할 때만 설치합니다.

`build-app.sh`는 Xcode·Swift·Go·FFmpeg·MediaMTX 버전과 Intel 아키텍처를 빌드 전에 검사합니다. 새 앱은 임시 경로에서 완전히 조립하고 plist, privacy manifest, 실행 파일 아키텍처와 코드 서명을 검증한 뒤에만 기존 앱을 교체합니다. 동시성 검사까지 포함하려면 `MACMONITOR_TSAN=1 ./scripts/build-app.sh`를 사용합니다.

`diagnose.sh`는 앱을 실행하기 전에 VideoToolbox 합성 프레임 인코딩, 번들과 helper, 설정 파일, 파일 권한 및 디스크 여유를 한 번에 확인합니다. `[FAIL]`이 있으면 감시를 시작하지 말고 해당 항목을 먼저 해결합니다. 최초 실행 전에는 앱 데이터와 생성된 MediaMTX 설정이 없다는 `[WARN]`이 정상입니다. 다른 위치의 앱을 검사하려면 `./scripts/diagnose.sh --app "/absolute/path/MacMonitor.app"`을 사용합니다.

앱 메뉴에서 `움직임 녹화 시작`을 누르고 카메라 권한을 승인합니다. 우선 외부 HTTPS 없이 로컬 캡처, 움직임 감지, 인코딩 및 녹화가 동작하는지 확인합니다.

앱 최초 실행 시 12자 이상 비밀번호를 설정합니다. 다음 실행부터는 이 비밀번호를 확인한 뒤에 메뉴와 감시 기능을 사용할 수 있습니다. 설정의 `앱 비밀번호 변경`에서 현재 비밀번호를 확인한 후 변경합니다. 앱 비밀번호는 macOS 관리자 인증이나 HTTPS 소유자 비밀번호와 별개이며, 원문 대신 솔트와 PBKDF2-SHA256 검증값을 키체인에 저장합니다.

진단 로그:

```text
~/Library/Application Support/MacMonitor/Diagnostics/
```

`capture-probe.jsonl`, `ffmpeg.log`, `mediamtx.log`, `gateway.log`를 순서대로 확인합니다.

## 3. 앱 설정

메뉴 막대에서 `설정…`을 열어 다음 값을 저장합니다.

- 외부 WebRTC 호스트: 휴대폰에서 도달할 DDNS 도메인 또는 공인 IP. 스킴과 포트 없이 입력합니다.
- 비트레이트: 초기값 1200kbps.
- 움직임 임계값: 초기값 18 / 변화 비율 0.025.
- 보관 기간·최대 용량·최소 디스크 여유.
- 움직임 전/후 보존 시간: 30초, 1분, 2분, 5분 등을 각각 선택. 움직임이 이어지면 마지막 감지 시각에서 사후 시간이 연장됩니다.
- 로그인 시 앱 실행 여부. 앱 비밀번호 확인 후 원격 대기 상태가 됩니다. 녹화는 메뉴의 `원격 시청 대기`를 끈 경우에만 함께 시작합니다. 먼저 수동 실행해 카메라 권한을 승인한 뒤 켭니다.
- 매일 예약 휴식: 기본 예시 23:00~06:00. 휴식 모드에서 `시스템 잠자기 → 깨운 직후 화면 끄기` 또는 `시스템 유지 · 화면만 끄기`를 선택합니다.

설정은 다음 카메라 시작부터 적용됩니다.

시스템 잠자기 모드는 저장 즉시 관리자 인증을 거쳐 전원 예약을 등록합니다. 앱은 예약 잠자기 1분 전 감시와 녹화를 정리하고 깨우기 이후 재개합니다. 예약 깨우기 시각 전후 2분 이내에 깨어나면 약 1초 뒤 `pmset displaysleepnow`를 한 번 실행합니다. 화면이 잠깐 켜질 수 있으며 완전한 무점등을 보장하지 않습니다. 최근 키보드·마우스 입력이 있으면 화면 끄기를 건너뜁니다. OS 알림으로 깨우기 원인을 확정할 수 없으므로 예약 시각 근처의 다른 원인 깨우기에도 적용될 수 있습니다.

화면만 끄기 모드는 앱이 시스템 유휴 잠자기 방지 assertion을 유지하고 휴식 시작에 화면만 끕니다. 휴식 동안 카메라·녹화·송출을 중지하고 재개 시각에 화면을 켜는 명령 없이 감시를 시작합니다. 예약 확인 주기는 10초입니다. 사용자가 화면을 깨우면 반복해서 끄지 않습니다. 앱 종료 또는 예약 해제 시 잠자기 방지를 해제합니다. 수동 잠자기·덮개 닫기·배터리 부족은 막지 않으며, 이 모드는 시스템 예약 깨우기를 등록하지 않습니다.

전원이 연결된 로그인 세션에서 앱을 계속 실행·인증한 채 두세요. 다른 앱이나 하드웨어에 영향을 받으므로 실기 검증이 필요합니다. 종료/재부팅 후 무인 로그인은 지원하지 않습니다. 시스템 잠자기 시각을 지난 뒤 예약을 적용하면 즉시 강제 잠자기를 실행하지 않으며 다음 예약 시각부터 적용됩니다.

시스템 잠자기 예약은 Mac 전체의 반복 전원 예약을 교체하며 앱 종료 후에도 유지됩니다. 해제하려면 `매일 예약 사용`을 끄거나 화면만 끄기로 전환하고 저장합니다. 적용 창에 표시되는 현재 예약을 확인하세요. 화면만 끄기 모드 자체는 관리자 인증이나 시스템 예약 변경이 필요 없으며 다른 프로그램의 전원 예약은 그대로 둡니다. 따라서 다른 프로그램이 등록한 잠자기 예약은 따로 확인해야 합니다.

자동 실행을 켜면 `~/Library/LaunchAgents/local.macmonitor.app.plist`가 생성되고 다음 로그인부터 LaunchServices를 통해 현재 앱 경로를 엽니다. 앱을 다른 폴더로 옮긴 경우 기존 앱에서 자동 실행을 끈 뒤 새 위치의 앱에서 다시 켜 경로를 갱신합니다.

## 4. HTTPS 인증서와 소유자 비밀번호

휴대폰이 신뢰하는 도메인 인증서의 full chain과 개인 키를 Mac에 둡니다. 개인 키 파일 권한은 소유자만 읽도록 제한합니다. 인증서 발급 방식은 사용하는 DDNS 및 DNS 사업자에 맞춰 결정하며, 앱이 임의로 인증서를 발급하거나 공유기 설정을 변경하지 않습니다.

앱을 한 번 빌드한 후 다음을 실행합니다.

```bash
./scripts/configure-gateway.sh \
  "https://camera.example.net:8443" \
  "/absolute/path/fullchain.pem" \
  "/absolute/path/privkey.pem"
```

12자 이상의 소유자 비밀번호를 두 번 입력합니다. macOS 터미널에서는 `stty`로 입력 표시를 잠시 끄며 셸 명령 기록에도 들어가지 않습니다. 저장 파일에는 원문이 아니라 600,000회 PBKDF2-SHA256 해시만 기록됩니다.

생성 파일:

```text
~/Library/Application Support/MacMonitor/gateway.json
```

설정 스크립트는 임시 파일을 만들어 게이트웨이를 열지 않은 채 JSON, 인증서/개인키 일치, 인증서 유효기간과 공개 호스트명, 개인키 권한, 녹화 경로를 검사합니다. 검증에 성공한 파일만 기존 `gateway.json`과 교체하며, 실패하면 기존 설정을 유지합니다. 인증된 앱이 실행 중이면 웹 설정 생성·변경을 최대 약 10초 주기로 감지해 적용합니다. 인증서 내용만 같은 경로에서 교체한 경우에는 `./scripts/diagnose.sh`를 다시 실행한 뒤 메뉴의 `원격 웹 다시 시작`을 누릅니다. 웹 서버 재시작은 웹 로그인 세션을 초기화하지만 촬영·녹화를 중단하지 않습니다.

HTTPS 웹 서버는 앱 비밀번호 확인 후 카메라와 독립적으로 실행됩니다. `움직임 녹화 중지`나 `시스템 유지 · 화면만 끄기` 예약 휴식 중에도 웹 로그인·녹화 목록·재생을 사용할 수 있습니다. 카메라를 다시 시작해도 설정이 같으면 웹 서버와 기존 로그인을 유지합니다. 앱을 종료하거나 Mac이 실제 잠자기에 들어가면 접속할 수 없으며, 깨어난 뒤 앱이 웹 서버를 다시 시작합니다. 메뉴의 `원격 시청 대기`가 켜져 있으면 화면은 꺼져도 시스템 유휴 잠자기를 막아 접속할 수 있는 상태를 유지하고, 끄면 일반 자동 잠자기를 막지 않습니다.

### 같은 Wi-Fi에서 먼저 시험하기

도메인과 포트포워딩 없이 자체 서명 인증서로 원격 시청 흐름을 먼저 확인할 수 있습니다. 앱을 한 번 빌드한 뒤 터미널에서 실행합니다. 경로는 압축을 푼 폴더에 맞게 바꿉니다.

```bash
mkdir -p ~/macmonitor-cert && cd ~/macmonitor-cert
IP=$(ipconfig getifaddr en0 || ipconfig getifaddr en1)
cat > cert.cnf <<EOF
[req]
distinguished_name = dn
x509_extensions = v3
prompt = no
[dn]
CN = MacMonitor LAN Test
[v3]
subjectAltName = IP:$IP
EOF
openssl req -x509 -newkey rsa:2048 -nodes -days 30 -keyout key.pem -out cert.pem -config cert.cnf
chmod 600 key.pem
~/Downloads/MacMonitor/scripts/configure-gateway.sh "https://$IP:8443" "$HOME/macmonitor-cert/cert.pem" "$HOME/macmonitor-cert/key.pem"
echo "https://$IP:8443"
```

웹 접속 비밀번호를 12자 이상으로 두 번 입력합니다. 앱이 약 10초 안에 설정을 감지합니다. 같은 Wi-Fi의 휴대폰에서 마지막 줄의 주소를 열고, 인증서 경고는 이 시험에서만 진행을 선택합니다. macOS 방화벽이 수신 연결을 물으면 허용합니다. 외부망에서 쓸 때는 신뢰할 수 있는 인증서와 실제 도메인으로 같은 스크립트를 다시 실행합니다.

## 5. 공유기 포트포워딩

권장 초기 매핑:

| 외부 | iMac 내부 | 용도 |
|---|---|---|
| TCP 8443 | TCP 8443 | HTTPS 웹, 인증, WebRTC 협상, 녹화 재생 |
| UDP 8189 | UDP 8189 | WebRTC ICE 미디어 |
| TCP 8189 | TCP 8189 | UDP가 차단된 환경의 ICE fallback |

다음 포트는 외부로 열지 않습니다.

- TCP 8554: 내부 RTSP 게시
- TCP 8889: MediaMTX WebRTC HTTP listener
- MediaMTX API, metrics, playback 포트

iMac의 내부 주소가 바뀌지 않도록 공유기의 DHCP 예약을 설정합니다. 포트포워딩은 사용자가 필요할 때 직접 열고 닫습니다.

## 6. 외부망 확인

Wi-Fi를 끈 휴대폰 데이터망에서 다음 순서로 확인합니다.

1. `https://camera.example.net:8443` 접속.
2. 잘못된 비밀번호가 거절되고 반복 실패가 제한되는지 확인.
3. 로그인하면 `카메라 켜는 중…` 뒤에 실시간 영상이 재생되고 iMac의 카메라 표시등이 켜지는지 확인. 창을 닫으면 약 20초 뒤 꺼지는지 확인.
4. 움직임 녹화를 켠 경우, 마지막 움직임부터 `사후 보존 + 사전 보존 + 약 7~9초` 기다린 뒤 녹화 목록을 갱신하고 MP4를 탐색 재생합니다. 앞뒤 30초이면 약 69초, 앞뒤 1분이면 약 129초입니다. 병합 실패 시 원본 세그먼트를 보존합니다.
5. 로그아웃 후 영상·녹화 URL이 401로 거절되는지 확인.
6. 이 전 과정에서 iMac 화면이 켜지거나 잠금이 풀리지 않는지 직접 관찰.

연결이 되지 않으면 공인 주소와 공유기 WAN 주소를 비교해 CGNAT/이중 NAT 여부부터 확인합니다. TCP 8443은 되지만 영상만 안 나오면 UDP/TCP 8189 전달, 앱 설정의 외부 WebRTC 호스트, 통신사 NAT를 순서대로 확인합니다. 이 프로젝트는 중계 서버를 사용하지 않으므로 포트포워딩 가능한 공인 주소가 직접 연결의 전제입니다.
