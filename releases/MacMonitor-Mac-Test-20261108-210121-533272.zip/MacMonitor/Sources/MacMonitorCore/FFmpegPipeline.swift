import CoreMedia
import CoreVideo
import Darwin
import Foundation

public struct FFmpegPipelineConfiguration {
    public let executableURL: URL
    public let spoolDirectory: URL
    public let rtspPublishURL: URL
    public let logURL: URL
    public let width: Int
    public let height: Int
    public let framesPerSecond: Int
    public let bitrateKbps: Int
    public let segmentSeconds: Int
    /// Stem of the clip files: motion spool segments and remote clips must stay distinguishable.
    public let segmentFilePrefix: String
    /// False publishes the live stream only and writes nothing to the spool.
    public let recordingEnabled: Bool

    public init(
        executableURL: URL,
        spoolDirectory: URL,
        rtspPublishURL: URL,
        logURL: URL,
        width: Int = 1280,
        height: Int = 720,
        framesPerSecond: Int = 15,
        bitrateKbps: Int = 1_200,
        segmentSeconds: Int = 5,
        segmentFilePrefix: String = "segment",
        recordingEnabled: Bool = true
    ) {
        self.executableURL = executableURL
        self.spoolDirectory = spoolDirectory
        self.rtspPublishURL = rtspPublishURL
        self.logURL = logURL
        self.width = width
        self.height = height
        self.framesPerSecond = framesPerSecond
        self.bitrateKbps = bitrateKbps
        self.segmentSeconds = segmentSeconds
        self.segmentFilePrefix = segmentFilePrefix
        self.recordingEnabled = recordingEnabled
    }
}

public final class FFmpegPipeline {
    public var failureHandler: ((Error) -> Void)?

    private let configuration: FFmpegPipelineConfiguration
    private let writerQueue = DispatchQueue(label: "com.macmonitor.ffmpeg.writer")
    private let stateLock = NSLock()
    private var process: Process?
    private var inputHandle: FileHandle?
    private var logHandle: FileHandle?
    private var acceptingFrames = false
    private var terminationSignal = DispatchSemaphore(value: 0)
    private var latestFrame: Data?
    private var pacer: ConstantRateFramePacer
    private var pacingTimer: DispatchSourceTimer?

    public init(configuration: FFmpegPipelineConfiguration) {
        self.configuration = configuration
        pacer = ConstantRateFramePacer(framesPerSecond: configuration.framesPerSecond)
    }

    public func start() throws {
        try FileManager.default.createDirectory(
            at: configuration.spoolDirectory,
            withIntermediateDirectories: true
        )
        try FileManager.default.createDirectory(
            at: configuration.logURL.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        try LogFileRotator.rotateIfNeeded(at: configuration.logURL)
        if !FileManager.default.fileExists(atPath: configuration.logURL.path) {
            FileManager.default.createFile(atPath: configuration.logURL.path, contents: nil)
        }

        let logHandle = try FileHandle(forWritingTo: configuration.logURL)
        logHandle.seekToEndOfFile()
        let inputPipe: Pipe
        do {
            inputPipe = try Self.makeInputPipe()
        } catch {
            try? logHandle.close()
            throw error
        }
        let process = Process()
        process.executableURL = configuration.executableURL
        process.arguments = arguments()
        process.standardInput = inputPipe
        process.standardOutput = logHandle
        process.standardError = logHandle
        let terminationSignal = DispatchSemaphore(value: 0)
        self.terminationSignal = terminationSignal
        process.terminationHandler = { [weak self] terminatedProcess in
            guard let self else { return }
            self.stateLock.lock()
            let ownsProcess = self.process.map { $0 === terminatedProcess } ?? false
            let wasUnexpected = ownsProcess && self.acceptingFrames
            if ownsProcess {
                self.acceptingFrames = false
            }
            let failureHandler = self.failureHandler
            self.stateLock.unlock()
            terminationSignal.signal()
            if wasUnexpected {
                failureHandler?(FFmpegPipelineError.unexpectedExit(terminatedProcess.terminationStatus))
            }
        }

        stateLock.lock()
        self.process = process
        inputHandle = inputPipe.fileHandleForWriting
        self.logHandle = logHandle
        latestFrame = nil
        pacer.reset()
        acceptingFrames = true
        stateLock.unlock()

        do {
            try process.run()
        } catch {
            stateLock.lock()
            acceptingFrames = false
            self.process = nil
            inputHandle = nil
            self.logHandle = nil
            latestFrame = nil
            stateLock.unlock()
            try? inputPipe.fileHandleForWriting.close()
            try? logHandle.close()
            throw error
        }

        startPacing()
    }

    /// Make a broken encoder pipe report EPIPE instead of terminating the app
    /// with SIGPIPE. The write error can then reach coordinated recovery.
    static func makeInputPipe() throws -> Pipe {
        let pipe = Pipe()
        guard fcntl(pipe.fileHandleForWriting.fileDescriptor, F_SETNOSIGPIPE, 1) == 0 else {
            throw FFmpegPipelineError.inputWriteFailed(NSError(domain: NSPOSIXErrorDomain, code: Int(errno)))
        }
        return pipe
    }

    /// Writes to the FFmpeg pipe on the clock rather than on frame arrival, so that the
    /// `-framerate` the input is configured with is what the stream actually carries.
    private func startPacing() {
        let interval = 1 / Double(max(configuration.framesPerSecond, 1))
        let timer = DispatchSource.makeTimerSource(queue: writerQueue)
        timer.schedule(deadline: .now() + interval, repeating: interval, leeway: .milliseconds(2))
        timer.setEventHandler { [weak self] in
            self?.emitDueFrames(uptime: ProcessInfo.processInfo.systemUptime)
        }
        stateLock.lock()
        let previous = pacingTimer
        pacingTimer = timer
        stateLock.unlock()
        previous?.cancel()
        timer.resume()
    }

    private func emitDueFrames(uptime: TimeInterval) {
        stateLock.lock()
        guard acceptingFrames, let frame = latestFrame, let handle = inputHandle else {
            stateLock.unlock()
            return
        }
        let dueCount = pacer.framesDue(at: uptime)
        stateLock.unlock()
        guard dueCount > 0 else { return }

        do {
            for _ in 0..<dueCount {
                try handle.write(contentsOf: frame)
            }
        } catch {
            reportWriteFailure(error)
        }
    }

    public func consume(sampleBuffer: CMSampleBuffer) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        stateLock.lock()
        let isAccepting = acceptingFrames
        stateLock.unlock()
        guard isAccepting else { return }

        guard let frame = NV12FrameCopier.copy(
            pixelBuffer: pixelBuffer,
            width: configuration.width,
            height: configuration.height
        ) else { return }

        // The pacing timer owns the pipe. Handing the newest frame over keeps the capture
        // thread free of the blocking write, and a frame that arrives late is repeated by the
        // pacer rather than shortening the encoded timeline.
        stateLock.lock()
        if acceptingFrames {
            latestFrame = frame
        }
        stateLock.unlock()
    }

    public func stop() {
        stateLock.lock()
        acceptingFrames = false
        let pacingTimer = self.pacingTimer
        self.pacingTimer = nil
        latestFrame = nil
        let process = self.process
        let inputHandle = self.inputHandle
        let terminationSignal = self.terminationSignal
        let logHandle = self.logHandle
        self.inputHandle = nil
        self.process = nil
        self.logHandle = nil
        stateLock.unlock()

        pacingTimer?.cancel()
        // Closing stdin first gives FFmpeg EOF and also releases a writer blocked on the pipe.
        try? inputHandle?.close()
        if let process, process.isRunning {
            if terminationSignal.wait(timeout: .now() + 5) == .timedOut {
                process.terminate()
                if terminationSignal.wait(timeout: .now() + 2) == .timedOut, process.isRunning {
                    kill(process.processIdentifier, SIGKILL)
                    _ = terminationSignal.wait(timeout: .now() + 1)
                }
            }
        }
        writerQueue.sync {}
        try? logHandle?.close()
    }

    private func reportWriteFailure(_ error: Error) {
        stateLock.lock()
        let shouldReport = acceptingFrames
        acceptingFrames = false
        let failureHandler = self.failureHandler
        stateLock.unlock()
        if shouldReport {
            failureHandler?(FFmpegPipelineError.inputWriteFailed(error))
        }
    }

    func arguments() -> [String] {
        let segmentPattern = configuration.spoolDirectory
            .appendingPathComponent("\(configuration.segmentFilePrefix)-%Y%m%dT%H%M%S.mp4")
            .path
        // A local publish failure must restart the pipeline; silently dropping
        // this slave would leave monitoring 'running' without any live video.
        var teeOutputs = ["[f=rtsp:rtsp_transport=tcp:onfail=abort]\(configuration.rtspPublishURL.absoluteString)"]
        if configuration.recordingEnabled {
            // Recording is essential: surface a failed output through process termination
            // so MonitoringCoordinator can recover instead of silently losing recordings.
            teeOutputs.append("[f=segment:segment_time=\(configuration.segmentSeconds):segment_time_delta=0.033:reset_timestamps=1:strftime=1:segment_format=mp4:segment_format_options=movflags=+faststart:onfail=abort]\(segmentPattern)")
        }
        let teeTarget = teeOutputs.joined(separator: "|")

        return [
            "-hide_banner", "-loglevel", "warning", "-nostdin",
            "-f", "rawvideo",
            "-pixel_format", "nv12",
            "-video_size", "\(configuration.width)x\(configuration.height)",
            "-framerate", "\(configuration.framesPerSecond)",
            "-i", "pipe:0",
            "-map", "0:v:0",
            "-an",
            "-c:v", "h264_videotoolbox",
            "-realtime", "true",
            "-allow_sw", "1",
            "-profile:v", "main",
            "-b:v", "\(configuration.bitrateKbps)k",
            "-maxrate", "\(configuration.bitrateKbps * 5 / 4)k",
            "-bufsize", "\(configuration.bitrateKbps * 2)k",
            "-g", "\(configuration.framesPerSecond * 2)",
            "-force_key_frames", "expr:gte(t,n_forced*\(configuration.segmentSeconds))",
            "-bf", "0",
            "-flags", "+cgop+global_header",
            "-f", "tee",
            "-use_fifo", "1",
            teeTarget
        ]
    }

    deinit {
        stop()
    }
}

public enum FFmpegPipelineError: LocalizedError {
    case unexpectedExit(Int32)
    case inputWriteFailed(Error)

    public var errorDescription: String? {
        switch self {
        case let .unexpectedExit(status):
            return "FFmpeg 영상 파이프라인이 예기치 않게 종료되었습니다 (상태 \(status))."
        case let .inputWriteFailed(error):
            return "FFmpeg에 영상 프레임을 전달하지 못했습니다: \(error.localizedDescription)"
        }
    }
}
