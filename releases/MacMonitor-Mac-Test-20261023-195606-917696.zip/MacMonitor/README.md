# MacMonitor

2015 Intel iMac과 macOS 12 Monterey를 대상으로 하는 개인용 CCTV입니다. 메뉴 막대 앱이 카메라를 소유하고, 하나의 H.264 인코딩 결과를 로컬 움직임 녹화와 MediaMTX WebRTC에 함께 사용합니다.

## 구현된 수직 경로

```text
AVFoundation 720p/15fps
  ├─ 저해상도 luma 움직임 분석
  └─ FFmpeg h264_videotoolbox 단일 인코딩
       ├─ 5초 MP4 임시 버퍼 → 설정한 감지 전후 구간 선택 → 사건별 MP4 병합
       └─ loopback RTSP → MediaMTX → WebRTC

휴대폰 HTTPS
  → Go 인증 게이트웨이
      ├─ 로그인/세션/CSRF/시도 제한
      ├─ 인증된 MediaMTX WebRTC 프록시
      └─ 인증된 녹화 목록/Range 재생
```

구현 항목:

- macOS 12용 메뉴 막대 앱과 설정 창
- 앱 실행 비밀번호 (최초 설정, 키체인에 PBKDF2 검증값 저장)
- 사용자 선택형 로그인 자동 실행 및 비밀번호 확인 후 감시 시작
- 매일 예약 잠자기·깨우기와 기존 앱 세션의 감시 재개
- 카메라 권한·장치 선택, 720p/15fps NV12 캡처, 프레임 하트비트
- 화면 절전은 허용하고 시스템 자동 유휴 잠자기만 방지
- 전역 밝기 변화를 보정한 움직임 감지
- VideoToolbox H.264 단일 인코딩과 RTSP/MP4 tee
- 감지 전후 30초·1분·2분·5분 등 선택, 움직임과 무관한 구간 자동 삭제, 사건별 MP4 무재인코딩 병합
- 기간·용량·최소 여유 공간 보관 정책
- 진단 로그별 10MB 제한과 최근 3세대 자동 회전
- MediaMTX의 RTSP/HTTP listener를 loopback으로 제한
- 고정 UDP/TCP 8189 WebRTC ICE 포트
- PBKDF2-SHA256 비밀번호, Secure/HttpOnly/SameSite 세션, CSRF 및 로그인 제한
- HTTPS 뒤의 모바일 실시간 화면과 녹화 재생 화면
- 카메라 세션·FFmpeg·MediaMTX·HTTPS 게이트웨이 비정상 종료 감지, 2/5/15초 간격의 최대 3회 자동 복구 및 안전한 감시 종료
- 공식 체크섬을 검증하는 MediaMTX 설치 스크립트
- Swift 상태/움직임/보관 테스트와 Go 게이트웨이 테스트

## Mac에서 준비하고 실행

Mac으로 옮길 최신 소스 ZIP은 [releases](releases/)에 있습니다. 2026-10-20 재검토에서 발견한 다운로드·첫 화면·녹화·감시 복구 오류와 실제 실행한 검사는 [재점검 기록](docs/RECHECK_2026-10-20.md)에 정리했습니다. 실제 Mac에서의 Swift 빌드·카메라·전원 동작은 검증 전입니다.

전체 순서는 [docs/SETUP_MAC.md](docs/SETUP_MAC.md)에 있습니다. 요약하면 다음과 같습니다.

명령어 없이 실행하려면 Finder에서 저장소 루트의 `Build MacMonitor.command`를 더블클릭합니다. 필요한 MediaMTX 준비, 테스트, Thread Sanitizer, 앱 빌드, 실행 전 진단과 앱 실행까지 이어서 처리하며 전체 출력은 `dist/build-날짜-시간.log`에 저장합니다.

터미널에서 개별 실행하려면 다음 명령을 사용합니다.

```bash
chmod +x scripts/*.sh
./scripts/fetch-mediamtx.sh
./scripts/build-app.sh
./scripts/diagnose.sh
open dist/MacMonitor.app
```

빌드에는 Xcode 14.2, Go 1.26.x, 앱이 실제로 찾을 수 있는 경로의 FFmpeg가 필요합니다. 빌드 스크립트는 도구와 버전을 먼저 검사하고 Swift·Go 테스트 후 Intel `x86_64` 앱을 임시 번들에 조립합니다. 아키텍처·plist·privacy manifest·서명을 모두 확인한 번들만 `dist/MacMonitor.app`으로 교체하므로 패키징 실패 시 기존 앱은 유지됩니다. `MACMONITOR_TSAN=1 ./scripts/build-app.sh`로 Thread Sanitizer 테스트까지 포함할 수 있습니다.

`diagnose.sh`는 앱 실행 전에 VideoToolbox 실제 1프레임 인코딩, 번들 아키텍처와 서명, MediaMTX 버전과 생성 설정, 앱 데이터 권한을 확인합니다. 게이트웨이가 설정되어 있으면 JSON, 인증서/개인키 짝, 인증서 유효기간·호스트명, 녹화 경로도 서버를 열지 않고 검사합니다. 실패 항목이 하나라도 있으면 종료 코드 1을 반환합니다.

첫 실행 후 메뉴 막대의 `설정…`에서 외부 WebRTC 호스트와 움직임·보관 값을 저장하고 `감시 시작`을 선택합니다. 카메라 권한은 사용자가 직접 승인해야 합니다.

최초 실행에는 12자 이상의 앱 비밀번호를 설정합니다. 이후 앱 실행마다 입력해야 하며 웹 접속 비밀번호와는 별개입니다. 비밀번호는 앱 실행을 잠그는 기능이며 MP4 파일을 암호화하지는 않습니다.

설정에서 움직임 전후 보존 시간을 선택할 수 있습니다. 신규 설치는 앞뒤 각 30초이며 기존 설정은 종전 5초/15초를 유지합니다. 앞부분 보존을 위한 디스크 임시 버퍼는 계속 순환하지만 움직임과 관계없는 구간은 최종 녹화로 저장하지 않습니다. 사건 MP4는 마지막 움직임부터 `후 보존 + 전 보존 + 약 7~9초` 뒤에 완성됩니다.

`매일 예약 사용`에서 예를 들어 23:00 휴식 시작, 06:00 감시 재개를 지정하고 두 모드 중 선택합니다.

- **시스템 잠자기 → 깨운 직후 화면 끄기**: 관리자 인증 후 Mac 전체 전원 예약을 등록합니다. 1분 전 감시를 정리하고 예약 깨우기 후 화면 끄기를 한 번 요청하며 감시를 재개합니다. 화면이 잠깐 켜지는 현상까지 막지는 못합니다.
- **시스템 유지 · 화면만 끄기**: 시스템 유휴 잠자기를 막고 휴식 시작에 화면을 끕니다. 휴식 중 카메라·녹화는 중단하고 재개 시각에 다시 동작합니다. 화면을 켜는 명령은 보내지 않습니다. 최초 설정에는 관리자 인증이 필요 없지만 기존 시스템 잠자기 예약에서 전환하면 예약 해제 인증이 필요합니다.

두 모드 모두 앱을 실행·인증한 상태로 두어야 합니다. 키보드·마우스 사용은 우선하며 화면을 반복해서 끄지 않습니다. 수동 잠자기·덮개 닫기·전원 차단까지 방지하지는 않습니다. 로그아웃/재부팅 후에는 앱 비밀번호를 다시 입력해야 합니다. 앱 종료 시 화면 전용 모드의 잠자기 방지는 해제되지만 시스템 전원 예약은 남으므로 설정에서 예약을 끄고 저장해 해제하세요.

## 애플리케이션 데이터

```text
~/Library/Application Support/MacMonitor/
├── config.json
├── gateway.json
├── Diagnostics/
├── Recordings/
├── Runtime/
└── Spool/
```

앱은 `Spool`과 `Recordings`만 보관 정책에 따라 정리합니다. 다른 디렉터리는 삭제 대상으로 삼지 않습니다.

## 아직 실제 Mac 검증이 필요한 항목

이 Windows 환경에서는 Swift/macOS 프레임워크를 컴파일하거나 카메라·VideoToolbox·전원 동작을 실행할 수 없습니다. MediaMTX 1.21.1 설정 기동, Go 테스트 및 macOS/amd64 교차 빌드는 여기서 확인했지만 아래 항목은 대상 iMac에서 판정해야 합니다.

- Swift 패키지의 Xcode 14.2 컴파일
- 카메라 권한과 실제 720p/15fps 포맷
- `h264_videotoolbox` 인코더 및 FFmpeg tee 동작
- 화면 꺼짐·잠금 상태의 프레임/녹화 지속
- 휴대폰 데이터망 WebRTC와 공유기 NAT 후보
- TLS 인증서, DDNS, 포트포워딩
- 장시간 CPU·메모리·발열·디스크 사용
- 인코딩된 내용 길이가 벽시계 시간과 일치하는지 (세그먼트 간격 5초 유지)

검증 절차는 [docs/MAC_VALIDATION.md](docs/MAC_VALIDATION.md), 네트워크 경계는 [docs/NETWORK_SECURITY.md](docs/NETWORK_SECURITY.md)를 따릅니다. 2026-10-07 신뢰성 수정의 변경 내용과 미검증 범위는 [docs/RELIABILITY_FIXES.md](docs/RELIABILITY_FIXES.md)에 있습니다.
