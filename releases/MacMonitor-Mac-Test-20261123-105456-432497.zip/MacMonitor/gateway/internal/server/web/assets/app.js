(() => {
  "use strict";

  const state = { csrfToken: "", liveLoaded: false, view: "live", mediaReachable: null, statusCheck: 0, recordingsCheck: 0,
    recordingOffset: 0, recordingLimit: 50, recordingRange: {}, recordingsLoading: false, recordingHasMore: false,
    protectionWrites: new Set(), wakingSince: 0, wakeCheck: null, recordingError: false, lastHealth: null };
  const loginPanel = document.querySelector("#login-panel");
  const app = document.querySelector("#app");
  const connection = document.querySelector("#connection");
  const loginForm = document.querySelector("#login-form");
  const loginError = document.querySelector("#login-error");
  const livePlayer = document.querySelector("#live-player");
  const liveUnavailable = document.querySelector("#live-unavailable");
  const liveWaiting = document.querySelector("#live-waiting");
  const mediaStatus = document.querySelector("#media-status");
  const monitorState = document.querySelector("#monitor-state");
  const monitorDetail = document.querySelector("#monitor-detail");
  const recordingsContainer = document.querySelector("#recordings");
  const recordingsEmpty = document.querySelector("#recordings-empty");
  const recordingTemplate = document.querySelector("#recording-template");
  const recordingFrom = document.querySelector("#recording-from");
  const recordingTo = document.querySelector("#recording-to");
  const recordingResults = document.querySelector("#recording-results");
  const previousRecordings = document.querySelector("#previous-recordings");
  const nextRecordings = document.querySelector("#next-recordings");
  const protectedOnly = document.querySelector("#protected-only");
  const protectionMessage = document.querySelector("#protection-message");
  const liveQuality = document.querySelector("#live-quality");
  const recordHours = document.querySelector("#record-hours");
  const recordStart = document.querySelector("#record-start");
  const recordStop = document.querySelector("#record-stop");
  const recordState = document.querySelector("#record-state");
  const talkButton = document.querySelector("#talk-button");
  const talkVolume = document.querySelector("#talk-volume");
  const talkVolumeValue = document.querySelector("#talk-volume-value");
  const talkState = document.querySelector("#talk-state");
  try { const saved = localStorage.getItem("macmonitor-live-quality"); if (["auto", "original", "balanced", "low"].includes(saved)) liveQuality.value = saved; } catch { /* Private browsing may disable storage. */ }
  document.querySelector("#recording-timezone").textContent = `날짜·시각 기준: 접속 기기 (${Intl.DateTimeFormat().resolvedOptions().timeZone}). 녹화 시작 시각으로 검색합니다.`;

  async function request(url, options = {}) {
    const headers = new Headers(options.headers || {});
    if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
    if (state.csrfToken && options.method && !["GET", "HEAD"].includes(options.method)) {
      headers.set("X-CSRF-Token", state.csrfToken);
    }
    const response = await fetch(url, { ...options, headers, credentials: "same-origin" });
    const type = response.headers.get("Content-Type") || "";
    const body = type.includes("application/json") ? await response.json() : null;
    if (!response.ok) {
      if (response.status === 401 && state.csrfToken) showLogin();
      throw new Error(body?.error || `요청 실패 (${response.status})`);
    }
    return body;
  }

  function showAuthenticated(session) {
    state.csrfToken = session.csrfToken;
    loginPanel.hidden = true;
    app.hidden = false;
    connection.textContent = "인증됨";
    connection.classList.add("online");
    state.mediaReachable = null;
    selectView("live");
    sendLiveDemand();
    refreshStatus();
  }

  function showLogin() {
    state.csrfToken = "";
    state.statusCheck += 1;
    state.recordingsCheck += 1;
    state.mediaReachable = null;
    stopLive();
    stopWaking();
    liveUnavailable.hidden = true;
    renderHealth(null);
    clearRecordings();
    recordingFrom.value = "";
    recordingTo.value = "";
    protectedOnly.checked = false;
    state.protectionWrites = new Set();
    protectionMessage.textContent = "";
    document.querySelector("#protection-summary").textContent = "";
    document.querySelector("#protection-warning").hidden = true;
    state.recordingOffset = 0;
    state.recordingRange = {};
    state.recordingHasMore = false;
    state.recordingsLoading = false;
    recordingResults.textContent = "";
    updateRecordingPages();
    app.hidden = true;
    loginPanel.hidden = false;
    connection.textContent = "로그인 필요";
    connection.classList.remove("online");
  }

  function loadLive() {
    livePlayer.src = `/assets/live.html?quality=${encodeURIComponent(liveQuality.value || "auto")}&t=${Date.now()}`;
    state.liveLoaded = true;
  }

  function stopLive() {
    state.liveLoaded = false;
    livePlayer.removeAttribute("src");
  }

  function selectView(view) {
    state.view = view;
    document.querySelectorAll(".tab").forEach((item) => item.classList.toggle("active", item.dataset.view === view));
    document.querySelector("#live-view").hidden = view !== "live";
    document.querySelector("#recordings-view").hidden = view !== "recordings";
    if (view === "recordings") {
      stopLive();
      stopWaking();
      refreshRecordings();
    } else {
      for (const video of recordingsContainer.querySelectorAll("video")) video.pause();
    }
  }

  // Renews the lease that keeps the camera on. Only a visible live view asks for video, so
  // the camera turns off soon after the viewer leaves, closes the tab or backgrounds it.
  async function sendLiveDemand() {
    const session = state.csrfToken;
    if (!session || state.view !== "live" || document.hidden) return;
    try {
      await request("/api/live/demand", { method: "POST" });
    } catch (error) {
      if (state.csrfToken === session) console.warn("live demand failed", error.message);
    }
  }

  function stopWaking() {
    state.wakingSince = 0;
    if (state.wakeCheck !== null) clearTimeout(state.wakeCheck);
    state.wakeCheck = null;
    liveWaiting.hidden = true;
  }

  function renderWaking(health) {
    if (!state.wakingSince) state.wakingSince = Date.now();
    const elapsed = Math.floor((Date.now() - state.wakingSince) / 1000);
    // The app retries a failed start, in recording mode too, for as long as this view keeps
    // asking. Its own error text says what went wrong, so the viewer is not left guessing.
    const reason = String(health.detail || "").replace(/^오류\s*—\s*/, "") || "원인 미확인";
    const message = health.state === "failed" ? `카메라를 켜지 못했습니다 · ${reason} · 이 화면을 보는 동안 약 30초마다 다시 시도합니다`
      : elapsed >= 45 ? "카메라 시작이 늦어지고 있습니다 · Mac과 앱 상태를 확인하세요"
      : elapsed > 0 ? `카메라 켜는 중… ${elapsed}초` : "카메라 켜는 중…";
    mediaStatus.textContent = message;
    mediaStatus.classList.remove("online");
    liveWaiting.textContent = message;
    liveWaiting.hidden = false;
    if (state.wakeCheck !== null) clearTimeout(state.wakeCheck);
    state.wakeCheck = document.hidden ? null : setTimeout(() => { state.wakeCheck = null; refreshStatus(); }, 1500);
  }

  async function refreshStatus() {
    const session = state.csrfToken;
    if (!session) return;
    const check = ++state.statusCheck;
    try {
      const status = await request("/api/status");
      if (state.csrfToken !== session || check !== state.statusCheck) return;
      renderHealth(status.monitoring);
      renderRecording(status.recording, status.monitoring);
      const firstCheck = state.mediaReachable === null;
      const lostLive = state.mediaReachable === true && !status.mediaReachable;
      state.mediaReachable = Boolean(status.mediaReachable);
      const health = status.monitoring;
      // With standby on, the app starts the camera because this page asked, so a stopped
      // media server means "starting", not "unavailable".
      const canWake = health?.available === true && health.fresh === true && health.liveStandby === true;
      const cameraReady = !canWake || health.frameState === "receiving";
      if (state.mediaReachable && (state.liveLoaded || cameraReady)) {
        stopWaking();
        liveUnavailable.hidden = true;
        mediaStatus.textContent = "영상 서버 연결됨";
        mediaStatus.classList.add("online");
        if (state.view === "live" && !state.liveLoaded) loadLive();
      } else if (canWake) {
        if (!state.mediaReachable) stopLive();
        liveUnavailable.hidden = true;
        if (state.view === "live") renderWaking(health);
        else { stopWaking(); mediaStatus.textContent = "실시간 탭을 열면 카메라가 켜집니다"; mediaStatus.classList.remove("online"); }
      } else {
        stopWaking();
        stopLive();
        liveUnavailable.hidden = false;
        mediaStatus.textContent = "실시간 연결 불가 · 저장된 녹화는 이용 가능";
        mediaStatus.classList.remove("online");
        if (state.view === "live" && (firstCheck || lostLive)) selectView("recordings");
      }
    } catch (error) {
      if (state.csrfToken !== session || check !== state.statusCheck) return;
      mediaStatus.textContent = error.message;
      mediaStatus.classList.remove("online");
      renderHealth(null);
    }
  }

  function renderHealth(health) {
    state.lastHealth = health;
    const available = health?.available === true;
    const fresh = available && health.fresh === true;
    const receiving = fresh && health.state === "running" && health.frameState === "receiving";
    const labels = {
      starting: "카메라 시작 중", stopped: "카메라 꺼짐", stopping: "카메라 정리 중", standby: "원격 대기 중",
      scheduledRest: "예약 휴식 중", sleeping: "시스템 잠자기", recovering: "카메라 복구 중", failed: "카메라 오류",
    };
    let label = "상태 확인 불가";
    if (available && !fresh) label = "상태 갱신 지연";
    else if (fresh && health.state === "running") {
      label = receiving ? "새 프레임 수신 중" : health.frameState === "waiting" ? "첫 영상 대기 중" : "영상 프레임 정지 · 복구 확인 필요";
    } else if (fresh) label = labels[health.state] || label;
    monitorState.textContent = label;
    monitorState.classList.toggle("online", receiving);
    monitorState.classList.toggle("warning", !fresh || health?.frameState === "stalled" || health?.state === "failed");
    monitorDetail.textContent = available ? health.detail : "앱의 촬영 상태를 확인하지 못했습니다. 웹 접속 여부만으로 정상 촬영을 판단할 수 없습니다.";
    const fps = fresh && health.expectingFrames && Number.isFinite(health.captureFPS) ? `${health.captureFPS.toFixed(1)} fps` : "—";
    document.querySelector("#capture-fps").textContent = fps;
    document.querySelector("#recording-mode").textContent = !fresh ? "—"
      : health.captureMode === "timed" ? "켜짐 · 원격" : "꺼짐";
    document.querySelector("#audio-state").textContent = !fresh ? "—"
      : health.audio === "on" ? "켜짐" : health.audio === "unavailable" ? `없음 · ${health.audioDetail || "원인 미확인"}`
      : health.audio === "off" ? "꺼짐 (설정)" : "—";
    document.querySelector("#slim-state").textContent = !fresh ? "—" : health.slimDetail || (health.slimMode ? "켜짐" : "꺼짐");
    document.querySelector("#last-frame").textContent = formatTime(health?.lastFrameAt);
    document.querySelector("#last-recording").textContent = formatTime(health?.lastRecordingAt);
    document.querySelector("#disk-free").textContent = available && Number.isFinite(health.diskFreeBytes) ? formatBytes(health.diskFreeBytes) : "—";
    document.querySelector("#watchdog-count").textContent = available && Number.isInteger(health.watchdogRecoveries) ? `${health.watchdogRecoveries}회` : "—";
    const retentionWarning = document.querySelector("#retention-warning");
    retentionWarning.hidden = !available || !health.retentionWarning;
    retentionWarning.textContent = available && health.retentionWarning ? `${fresh ? "최근 보관 점검: " : "마지막 보고된 경고 (갱신 지연): "}${health.retentionWarning}` : "";
  }

  // The request lives in the gateway's file, not in this page: the owner may close the tab or
  // open another device, and the status answer is what every page agrees on.
  function renderRecording(recording, health) {
    const until = typeof recording?.until === "string" ? new Date(recording.until) : null;
    const active = until !== null && Number.isFinite(until.getTime());
    recordStart.hidden = active;
    recordStop.hidden = !active;
    recordHours.disabled = active;
    if (!active) {
      if (!state.recordingError) recordState.textContent = "";
      state.recordingError = false;
      return;
    }
    state.recordingError = false;
    const fresh = health?.available === true && health.fresh === true;
    const recordingNow = fresh && health.state === "running" && health.captureMode === "timed";
    const label = recordingNow ? "원격 녹화 중" : fresh ? "녹화 요청됨 · 카메라 준비 중" : "녹화 요청됨 · 앱 상태 확인 불가";
    const untilText = new Intl.DateTimeFormat("ko-KR", { hour: "2-digit", minute: "2-digit" }).format(until);
    recordState.textContent = `${label} · ${untilText}까지 · 남은 ${formatRemaining(until.getTime() - Date.now())}`;
  }

  function formatRemaining(milliseconds) {
    const minutes = Math.max(0, Math.ceil(milliseconds / 60000));
    const hours = Math.floor(minutes / 60);
    if (hours === 0) return `${minutes}분`;
    return minutes % 60 === 0 ? `${hours}시간` : `${hours}시간 ${minutes % 60}분`;
  }

  function formatTime(value) {
    if (!value) return "—";
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return "—";
    return new Intl.DateTimeFormat("ko-KR", { dateStyle: "short", timeStyle: "medium" }).format(date);
  }

  async function refreshRecordings() {
    const session = state.csrfToken;
    if (!session) return;
    const check = ++state.recordingsCheck;
    clearRecordings();
    state.recordingsLoading = true;
    updateRecordingPages();
    recordingResults.textContent = "녹화 검색 중…";
    document.querySelector("#protection-summary").textContent = "보호 현황 확인 중…";
    recordingsEmpty.textContent = "조건에 맞는 녹화가 없습니다.";
    recordingsEmpty.hidden = true;
    try {
      const params = new URLSearchParams({ ...state.recordingRange, offset: state.recordingOffset, limit: state.recordingLimit });
      const result = await request(`/api/recordings?${params}`);
      if (state.csrfToken !== session || check !== state.recordingsCheck) return;
      recordingsEmpty.hidden = result.recordings.length !== 0;
      state.recordingHasMore = result.hasMore;
      document.querySelector("#protection-summary").textContent = `전체 보관함 보호: ${result.protectedCount}개 · ${formatBytes(result.protectedBytes)}`;
      const protectionWarning = document.querySelector("#protection-warning");
      protectionWarning.hidden = !result.protectionWarning;
      protectionWarning.textContent = result.protectionWarning || "";
      const start = result.recordings.length ? state.recordingOffset + 1 : 0;
      recordingResults.textContent = `총 ${result.total}개 · ${start}–${start ? state.recordingOffset + result.recordings.length : 0} 표시`;
      for (const recording of result.recordings) {
        const card = recordingTemplate.content.firstElementChild.cloneNode(true);
        card.querySelector(".recording-date").textContent = new Intl.DateTimeFormat("ko-KR", {
          dateStyle: "medium", timeStyle: "medium"
        }).format(new Date(recording.startedAt));
        card.querySelector(".recording-size").textContent = formatBytes(recording.sizeBytes);
        const video = card.querySelector("video");
        const download = card.querySelector(".recording-download");
        download.href = recording.downloadURL;
        download.download = recording.id;
        const protect = card.querySelector(".recording-protect");
        const protectionLabel = card.querySelector(".recording-protection-state");
        protect.textContent = recording.protected ? "보호 해제" : "중요 녹화로 보호";
        protect.disabled = !recording.protectionSupported || !recording.protectionAvailable || state.protectionWrites.has(recording.id);
        protectionLabel.textContent = !recording.protectionAvailable ? "보호 상태 확인 불가" :
          !recording.protectionSupported ? "정리 중 · 완성 후 보호 가능" : recording.protected ? "보호 중 · 자동 삭제 제외" : "보관 기준에 따라 자동 정리";
        protectionLabel.classList.toggle("protected", recording.protected && recording.protectionAvailable);
        protect.addEventListener("click", async () => {
          if (protect.disabled || state.protectionWrites.has(recording.id)) return;
          const targetProtected = !recording.protected;
          if (!targetProtected && !confirm("보호를 해제하면 다음 자동 정리에서 이 녹화가 삭제될 수 있습니다. 중요한 영상은 먼저 다운로드하세요. 보호를 해제할까요?")) return;
          const writes = state.protectionWrites;
          writes.add(recording.id);
          protect.disabled = true;
          protectionMessage.textContent = "보호 설정 저장 중…";
          try {
            await request(`/api/recordings/${encodeURIComponent(recording.id)}/protection`, {
              method: "PUT", body: JSON.stringify({ protected: targetProtected }),
            });
            if (state.csrfToken === session) protectionMessage.textContent = targetProtected ? "중요 녹화로 보호했습니다. 자동 삭제에서 제외됩니다." : "보호를 해제했습니다. 이제 자동 정리 대상입니다.";
          } catch (error) {
            if (state.csrfToken === session) protectionMessage.textContent = error.message;
          } finally {
            writes.delete(recording.id);
            if (state.csrfToken === session) refreshRecordings();
          }
        });
        // Protected recordings cannot be deleted here: unprotecting first is the second look
        // that a tap on a phone otherwise lacks.
        const remove = card.querySelector(".recording-delete");
        const protectedNow = recording.protected && recording.protectionAvailable;
        remove.disabled = protectedNow || !recording.protectionAvailable || !recording.protectionSupported || state.protectionWrites.has(recording.id);
        remove.title = protectedNow ? "보호된 녹화는 먼저 보호를 해제해야 삭제할 수 있습니다" : "";
        remove.addEventListener("click", async () => {
          if (remove.disabled || state.protectionWrites.has(recording.id)) return;
          if (!confirm("이 녹화를 삭제할까요? 되돌릴 수 없습니다. 필요하면 먼저 다운로드하세요.")) return;
          const writes = state.protectionWrites;
          writes.add(recording.id);
          remove.disabled = true;
          protect.disabled = true;
          protectionMessage.textContent = "삭제 중…";
          try {
            await request(`/api/recordings/${encodeURIComponent(recording.id)}`, { method: "DELETE" });
            if (state.csrfToken === session) protectionMessage.textContent = "녹화를 삭제했습니다.";
          } catch (error) {
            if (state.csrfToken === session) protectionMessage.textContent = error.message;
          } finally {
            writes.delete(recording.id);
            if (state.csrfToken === session) refreshRecordings();
          }
        });
        const image = card.querySelector(".recording-thumbnail");
        const placeholder = card.querySelector(".thumbnail-placeholder");
        image.addEventListener("load", () => { placeholder.hidden = true; });
        image.addEventListener("error", () => {
          image.hidden = true;
          placeholder.hidden = false;
          placeholder.textContent = "미리보기 없음 · 재생 가능";
        });
        image.src = recording.thumbnailURL;
        card.querySelector(".recording-summary").addEventListener("click", () => {
          const opening = video.hidden;
          for (const other of recordingsContainer.querySelectorAll("video")) {
            if (other !== video) { other.pause(); other.hidden = true; other.removeAttribute("src"); other.load(); }
          }
          video.hidden = !opening;
          if (opening) video.src = recording.url;
          else { video.pause(); video.removeAttribute("src"); video.load(); }
        });
        video.hidden = true;
        recordingsContainer.append(card);
      }
    } catch (error) {
      if (state.csrfToken !== session || check !== state.recordingsCheck) return;
      recordingsEmpty.textContent = error.message;
      recordingsEmpty.hidden = false;
      recordingResults.textContent = "녹화 목록을 불러오지 못했습니다. 새로고침해 주세요.";
      document.querySelector("#protection-summary").textContent = "보호 현황 확인 불가";
      state.recordingHasMore = false;
    } finally {
      if (state.csrfToken === session && check === state.recordingsCheck) {
        state.recordingsLoading = false;
        updateRecordingPages();
      }
    }
  }

  function clearRecordings() {
    for (const video of recordingsContainer.querySelectorAll("video")) {
      video.pause(); video.removeAttribute("src"); video.load();
    }
    for (const image of recordingsContainer.querySelectorAll("img")) image.removeAttribute("src");
    recordingsContainer.replaceChildren();
  }

  function updateRecordingPages() {
    previousRecordings.disabled = state.recordingsLoading || state.recordingOffset === 0;
    nextRecordings.disabled = state.recordingsLoading || !state.recordingHasMore;
    document.querySelector("#recording-page").textContent = `${Math.floor(state.recordingOffset / state.recordingLimit) + 1} 페이지`;
  }

  function dateBoundary(value, nextDay) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("날짜를 확인해 주세요.");
    const date = new Date(`${value}T00:00:00`);
    const [year, month, day] = value.split("-").map(Number);
    if (!Number.isFinite(date.getTime()) || date.getFullYear() !== year || date.getMonth() + 1 !== month || date.getDate() !== day) throw new Error("날짜를 확인해 주세요.");
    if (nextDay) date.setDate(date.getDate() + 1); // Local calendar days, including DST.
    return date.toISOString();
  }

  document.querySelector("#recording-filter").addEventListener("submit", (event) => {
    event.preventDefault();
    try {
      if (recordingFrom.value && recordingTo.value && recordingFrom.value > recordingTo.value) throw new Error("시작 날짜가 끝 날짜보다 늦습니다.");
      const range = {};
      if (recordingFrom.value) range.from = dateBoundary(recordingFrom.value, false);
      if (recordingTo.value) range.to = dateBoundary(recordingTo.value, true);
      if (protectedOnly.checked) range.protected = "1";
      state.recordingRange = range;
      state.recordingOffset = 0;
      refreshRecordings();
    } catch (error) { recordingResults.textContent = error.message; }
  });
  document.querySelector("#clear-recording-filter").addEventListener("click", () => {
    recordingFrom.value = ""; recordingTo.value = ""; protectedOnly.checked = false;
    state.recordingRange = {}; state.recordingOffset = 0;
    refreshRecordings();
  });
  previousRecordings.addEventListener("click", () => {
    if (previousRecordings.disabled) return;
    state.recordingOffset = Math.max(0, state.recordingOffset - state.recordingLimit);
    refreshRecordings();
  });
  nextRecordings.addEventListener("click", () => {
    if (nextRecordings.disabled) return;
    state.recordingOffset += state.recordingLimit;
    refreshRecordings();
  });

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
    return `${(bytes / 1024 ** 3).toFixed(1)} GB`;
  }

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    loginError.textContent = "";
    const password = new FormData(loginForm).get("password");
    try {
      const session = await request("/api/login", { method: "POST", body: JSON.stringify({ password }) });
      loginForm.reset();
      showAuthenticated(session);
    } catch (error) {
      loginError.textContent = error.message;
    }
  });

  document.querySelector("#logout").addEventListener("click", async () => {
    try { await request("/api/logout", { method: "POST" }); } finally { showLogin(); }
  });
  document.querySelector("#reload-live").addEventListener("click", () => { stopLive(); sendLiveDemand(); refreshStatus(); });
  recordStart.addEventListener("click", async () => {
    const hours = Number(recordHours.value);
    if (!Number.isInteger(hours) || hours < 1 || hours > 24) {
      state.recordingError = true;
      recordState.textContent = "녹화 시간을 고르세요 (1~24시간)";
      return;
    }
    recordStart.disabled = true;
    try {
      const recording = await request("/api/recording/start", { method: "POST", body: JSON.stringify({ hours }) });
      renderRecording(recording, state.lastHealth);
      // Recording restarts the capture, so the player reconnects on its own after a short gap.
      refreshStatus();
    } catch (error) {
      state.recordingError = true;
      recordState.textContent = `녹화 시작 실패 · ${error.message}`;
    } finally {
      recordStart.disabled = false;
    }
  });
  recordStop.addEventListener("click", async () => {
    recordStop.disabled = true;
    try {
      await request("/api/recording/stop", { method: "POST" });
      renderRecording(null, null);
      refreshStatus();
    } catch (error) {
      state.recordingError = true;
      recordState.textContent = `녹화 중지 실패 · ${error.message}`;
    } finally {
      recordStop.disabled = false;
    }
  });
  liveQuality.addEventListener("change", () => {
    try { localStorage.setItem("macmonitor-live-quality", liveQuality.value); } catch { /* Preference remains valid for this page. */ }
    stopLive();
    if (state.csrfToken && state.view === "live") refreshStatus();
  });
  document.querySelector("#refresh-recordings").addEventListener("click", () => { state.recordingOffset = 0; refreshRecordings(); });

  // Push-to-talk: record while the button is held, send on release, and the Mac plays it.
  const talk = { stream: null, recorder: null, chunks: [], startedAt: 0, timer: 0, holding: false, sending: false };
  try {
    const saved = Number(localStorage.getItem("macmonitor-talk-volume"));
    if (Number.isInteger(saved) && saved >= 1 && saved <= 100) talkVolume.value = String(saved);
  } catch { /* Private browsing may disable storage. */ }
  talkVolumeValue.textContent = talkVolume.value;
  talkVolume.addEventListener("input", () => {
    talkVolumeValue.textContent = talkVolume.value;
    try { localStorage.setItem("macmonitor-talk-volume", talkVolume.value); } catch { /* The value still applies on this page. */ }
  });

  // iOS Safari records AAC in MP4; Chrome and Firefox record Opus in WebM or Ogg.
  function talkMimeType() {
    if (typeof MediaRecorder === "undefined") return null;
    for (const type of ["audio/webm;codecs=opus", "audio/mp4", "audio/webm", "audio/ogg;codecs=opus"]) {
      if (MediaRecorder.isTypeSupported?.(type)) return type;
    }
    return "";
  }

  function talkUnavailable() {
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) return "이 연결에서는 브라우저가 마이크를 막습니다. 인증서 경고 없이 열리는 HTTPS 주소에서만 됩니다.";
    if (talkMimeType() === null) return "이 브라우저는 녹음을 지원하지 않습니다.";
    return "";
  }

  function releaseTalkStream() {
    for (const track of talk.stream?.getTracks() || []) track.stop();
    talk.stream = null;
  }

  async function startTalk(event) {
    event.preventDefault();
    if (talk.holding || talk.sending || talk.recorder) return;
    const reason = talkUnavailable();
    if (reason) { talkState.textContent = reason; return; }
    talk.holding = true;
    try { talkButton.setPointerCapture(event.pointerId); } catch { /* Release is still caught by pointerup. */ }
    talkState.textContent = "마이크 준비 중";
    try {
      talk.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    } catch (error) {
      talk.holding = false;
      talkState.textContent = error?.name === "NotAllowedError" ? "마이크가 거부되었습니다. 브라우저 설정에서 이 사이트의 마이크를 허용하세요." : `마이크를 쓸 수 없습니다 · ${error?.message || error}`;
      return;
    }
    // Released while the permission prompt was open: nothing was said yet.
    if (!talk.holding) {
      releaseTalkStream();
      talkState.textContent = "마이크를 허용했습니다. 다시 누른 채로 말하세요.";
      return;
    }
    const type = talkMimeType();
    talk.chunks = [];
    try {
      talk.recorder = type ? new MediaRecorder(talk.stream, { mimeType: type }) : new MediaRecorder(talk.stream);
    } catch (error) {
      talk.holding = false;
      releaseTalkStream();
      talkState.textContent = `녹음을 시작하지 못했습니다 · ${error?.message || error}`;
      return;
    }
    talk.recorder.addEventListener("dataavailable", (chunk) => { if (chunk.data.size) talk.chunks.push(chunk.data); });
    talk.recorder.addEventListener("stop", sendTalk, { once: true });
    talk.recorder.start();
    talk.startedAt = performance.now();
    talkButton.classList.add("recording");
    talkState.textContent = "녹음 중 · 떼면 Mac으로 보냅니다";
    talk.timer = setTimeout(stopTalk, 60000);
  }

  function stopTalk() {
    talk.holding = false;
    clearTimeout(talk.timer);
    talkButton.classList.remove("recording");
    if (talk.recorder && talk.recorder.state !== "inactive") talk.recorder.stop();
  }

  async function sendTalk() {
    const recorder = talk.recorder;
    const chunks = talk.chunks;
    talk.recorder = null;
    talk.chunks = [];
    releaseTalkStream();
    const seconds = (performance.now() - talk.startedAt) / 1000;
    const type = recorder?.mimeType || chunks[0]?.type || "audio/webm";
    const clip = new Blob(chunks, { type });
    if (seconds < 0.5 || clip.size === 0) {
      talkState.textContent = "너무 짧습니다. 버튼을 누른 채로 말하세요.";
      return;
    }
    talk.sending = true;
    talkButton.disabled = true;
    talkState.textContent = "Mac으로 보내는 중";
    try {
      await request(`/api/talk?volume=${encodeURIComponent(talkVolume.value)}`, { method: "POST", body: clip, headers: { "Content-Type": type } });
      talkState.textContent = `Mac에서 재생했습니다 · ${Math.max(1, Math.round(seconds))}초`;
    } catch (error) {
      talkState.textContent = `재생 실패 · ${error.message}`;
    } finally {
      talk.sending = false;
      talkButton.disabled = false;
    }
  }

  talkButton.addEventListener("pointerdown", startTalk);
  for (const name of ["pointerup", "pointercancel", "lostpointercapture"]) {
    talkButton.addEventListener(name, () => { if (talk.holding) stopTalk(); });
  }
  talkButton.addEventListener("contextmenu", (event) => event.preventDefault());

  for (const tab of document.querySelectorAll(".tab")) {
    tab.addEventListener("click", () => {
      selectView(tab.dataset.view);
      if (state.view === "live") { sendLiveDemand(); refreshStatus(); }
    });
  }

  function pollWhileVisible() {
    if (state.csrfToken && !document.hidden) { sendLiveDemand(); refreshStatus(); }
  }
  setInterval(pollWhileVisible, 5000);
  document.addEventListener("visibilitychange", pollWhileVisible);

  request("/api/session").then((session) => {
    if (session.authenticated) showAuthenticated(session); else showLogin();
  }).catch(() => showLogin());
})();
